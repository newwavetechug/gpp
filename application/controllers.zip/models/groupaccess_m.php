<?php
class Groupaccess_m extends MY_Model
{
    public $_tablename='groupaccess';
    public $_primary_key='id';
    function __construct()
    {
        parent::__construct();


    }



}
 