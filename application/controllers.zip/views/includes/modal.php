 
	 
			<!--  <a id="modal-103453" href="#ppdamodel" role="button" class="btn" data-toggle="modal">Launch demo modal</a>
			
			 --><div id="ppdamodel" class="modal hide fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="width:800px; ">
				<div class="modal-header">
					 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<h3 id="modal-title" class="modal-ti">
						 
					</h3>
				</div>
				<div class="modal-body" id="modal-body">
					<p>
						One fine body…
					</p>
				</div>
				<div class="modal-footer">
					 <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button> <button class="btn btn-primary">Save changes</button>
				</div>
			</div>
		 
	 