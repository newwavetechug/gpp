<div class="row">

    <div class="col-md-12" style="margin:0 auto; text-align:center">
        <i class="fa fa-cop"></i> &#64 copyright PPDA All Rights Reserved | <a href="">Terms of use</a>
    </div>
</div>
<!-- Scripts in development mode -->
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/jspdf.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/libs/FileSaver.js/FileSaver.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/libs/Blob.js/Blob.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/libs/Blob.js/BlobBuilder.js"></script>

<script type="text/javascript" src="<?= base_url() ?>js/jspdf/libs/Deflate/deflate.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/libs/Deflate/adler32cs.js"></script>

<script type="text/javascript" src="<?= base_url() ?>js/jspdf/jspdf.plugin.addimage.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/jspdf.plugin.from_html.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/jspdf.plugin.ie_below_9_shim.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/jspdf.plugin.sillysvgrenderer.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/jspdf.plugin.split_text_to_size.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/jspdf/jspdf.plugin.standard_fonts_metrics.js"></script>

<script type="text/javascript" src="<?= base_url() ?>js/printThis/printThis.js"></script>
