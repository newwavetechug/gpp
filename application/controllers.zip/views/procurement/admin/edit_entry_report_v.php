
<!-- BEGIN RECENT ORDERS PORTLET-->

<div class="widget">
    <div class="widget-title">
        <h4><i class="icon-bar-chart"></i> Edit entry </h4>

                                        <span class="tools">

                                        <a href="javascript:;" class="icon-chevron-down"></a>
                                        <a href="javascript:;" class="icon-remove"></a>
                                        </span>
    </div>
    <div class="widget-body">
        <?=$this->load->view('procurement/admin/forms/edit_entry_f')?>

    </div>
</div>
<!-- END RECENT ORDERS PORTLET-->

