<div class="navbar-inverse">
    <form class="navbar-search visible-phone">
        <input type="text" class="search-query" placeholder="Search" />
    </form>
</div>