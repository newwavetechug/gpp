

    <div class="well">
        <div class="page-header" style="margin-top:0; color:#006E93">
            <h3>
                About this portal
            </h3>
        </div>
        <p style="color:#006D92">
            Welcome to the Register of Providers website. This is an online database that revolutionalizes the way business is conducted in our country. The main purpose of this register is to create a sustainable and vibrant web- based forum for Procuring and Disposing Entities (PDEs) to interact with Providers hence promoting a more transparent and enabling business environment.
        </p>

        <div style="width:100%; height:1px; background:#E4E4E4; margin:9px 0"></div>

        <p style="color:#006D92; font-weight:600">
            Welcome to the Register of Providers website. This is an online database that revolutionalizes the way business is conducted in our country.
        </p>

    </div>

