<div class="page-header col-lg-offset-2" style="margin:0">
    <h3>
        <?=date('l, d F Y')?>
    </h3>
</div>