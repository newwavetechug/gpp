<style>
.btn-sm, .btn-xs {
font-size: 9px;

   border-radius:0px;
  text-transform: uppercase;
}

</style>
<div class="row">
    <div class="col-md-12" style="margin:0 auto; text-align:center">
        <i class="fa fa-cop"></i>  <a href="#">Terms of use</a> | <a href="#">About This Portal</a> | <a href="<?=base_url().'admin/login/'; ?> ">Login As PPDA </a> | <a href="<?=base_url().'page/verifybeb/'; ?> ">Verify BEB </a>
        <br/>
        <a href="http://newwavetech.co.ug/" target="_blank" style="font-size:70%; text-decoration:none;">Developed at New Wave Technologies </a>
    </div>
</div>
<!-- &#64 copyright PPDA All Rights Reserved | -->
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/platform.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>