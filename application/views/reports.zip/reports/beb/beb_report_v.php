<?php
/**
 * Created by PhpStorm.
 * User: cengkuru
 * Date: 5/16/2015
 * Time: 11:04 AM
 */
$this->load->view('reports/report_template');