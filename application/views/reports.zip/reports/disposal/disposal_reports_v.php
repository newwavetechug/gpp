<?php
$this->load->view('reports/report_template');